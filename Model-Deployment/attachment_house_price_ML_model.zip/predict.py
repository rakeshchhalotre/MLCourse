import sys, json
import numpy as np
from sklearn.externals import joblib

data = json.loads(sys.argv[1])
data = np.array(data['data'])
sav = joblib.load('/var/www/html/hp_model.ml')
pred = sav.predict(data.reshape(1,-1))
result = int(round(pred[0],0))
result_a = format(abs(result),',')
print(result_a)

<?php
	$place = 0; $sq_ft = 0; $years_old = 0; $floor = 0; $total_floor = 0; $bhk = 1; $built_up = 0;
	
	$place = $_POST['location'];
	$sq_ft = $_POST['sq_ft'];
	$years_old = $_POST['years_old'];
	$floor = $_POST['floor'];
	$total_floor = $_POST['total_floor'];
	$bhk = $_POST['bhk'];
	$built_up = $_POST['built_up'];
	
	$jsonf = "'{\"data\":[$place,$sq_ft,$years_old,$floor,$total_floor,$bhk,$built_up]}'";
	$shells = "/usr/bin/python3 -W ignore /var/www/html/predict.py $jsonf";

	$result = exec($shells);
	echo $result;
	
?>
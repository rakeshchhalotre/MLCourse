<!DOCTYPE html>
<html lang='en'>
	<head>
		<meta charset="utf-8"> 
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<script>
			$(function () {
				$('form').on('submit', function(e) {
					e.preventDefault();
					$.ajax({
						type: 'post',
						url: 'prediction.php',
						data: $('form').serialize(),
						success: function(data) {
							document.getElementById('pred').innerHTML = data
						}
					});
				});

			});
		</script>
	</head>
	<body>
		<div class='container'>
			<div class='row'>
				<h1>House Price Prediction</h1>
				<h3>Prediction: <mark id='pred'></mark></h3>
				<form>
					<div class="form-group">
						<label for="location">Location</label>
							<select class="form-control" name="location">
								<option value="0">Abbaiah Reddy Layout</option>
								<option value="1">Ambalipura</option>
								<option value="2">BTM Layout</option>
								<option value="3">Devarabeesana Halli</option>
								<option value="4">Electronics City Phase 1</option>
								<option value="5">Frazer Town</option>
								<option value="6">Gunjur</option>
								<option value="7">KR Puram</option>
								<option value="8">Malleshwaram</option>
								<option value="9">Rajaji Nagar</option>
								<option value="10">Sarakki Nagar</option>
								<option value="11">Subramanyapura</option>
								<option value="12">White Field</option>
								<option value="13">Whitefield</option>
								<option value="14">Yelachenahalli</option>
							</select>
					</div> 
					<div class="form-group">
						<label for="bhk">BHK</label>
							<select class="form-control" name="bhk">
								<option value=1>1</option>
								<option value=2>2</option>
								<option value=3>3</option>
							</select>
					</div>
					<div class="form-group">
						<label for="text">Sq.ft</label>
						<input type="number" class="form-control" name="sq_ft" aria-describedby="inputGroupPrepend" required>
						<div class="invalid-feedback">
							Please input Square feet.
						</div>
					</div>
					<div class="form-group">
						<label for="years_old">Years Old</label>
							<select class="form-control" name="years_old">
								<option value=1>New</option>
								<option value=1>1</option>
								<option value=2>2</option>
								<option value=3>3</option>
								<option value=4>4</option>
								<option value=5>5</option>
								<option value=6>6</option>
								<option value=7>7</option>
								<option value=8>8</option>
								<option value=9>9</option>
								<option value=10>10</option>
								<option value=11>11</option>
								<option value=12>12</option>
								<option value=13>13</option>
								<option value=14>14</option>
								<option value=15>15</option>
							</select>
					</div>
					<div class="form-group">
						<label for="floor">Floor</label>
							<select class="form-control" name="floor">
								<option value=0>Ground Floor</option>
								<option value=1>1</option>
								<option value=2>2</option>
								<option value=3>3</option>
								<option value=4>4</option>
								<option value=5>5</option>
								<option value=6>6</option>
								<option value=7>7</option>
								<option value=8>8</option>
								<option value=9>9</option>
								<option value=10>10</option>
								<option value=11>11</option>
								<option value=12>12</option>
								<option value=13>13</option>
								<option value=14>14</option>
								<option value=15>15</option>
							</select>
					</div>

					<div class="form-group">
						<label for="floor">Total Floor</label>
							<select class="form-control" name="total_floor">
								<option value=1>1</option>
								<option value=2>2</option>
								<option value=3>3</option>
								<option value=4>4</option>
								<option value=5>5</option>
								<option value=6>6</option>
								<option value=7>7</option>
								<option value=8>8</option>
								<option value=9>9</option>
								<option value=10>10</option>
								<option value=11>11</option>
								<option value=12>12</option>
								<option value=13>13</option>
								<option value=14>14</option>
								<option value=15>15</option>
							</select>
					</div>


					<div class="form-group">
						<label for="years_old">Built</label>
							<select class="form-control" name="built_up">
								<option value="0">Built up</option>
								<option value="1">Super Built up</option>
							</select>
					</div>



					<button type="submit" class="btn btn-default" name='submit'>Submit</button>
				</form>
			</div>
		</div>
	</body>
</html>

# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 12:16:24 2018

@author: sae_x
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.preprocessing import LabelEncoder
from sklearn.externals import joblib

data = pd.read_csv("hp_data.csv")
data = data.iloc[:,1:]

le = LabelEncoder()
data.iloc[:,1] = le.fit_transform(data.iloc[:,1])
le.classes_

X = data.drop(["price"], axis = 1)
y = data["price"]

X = pd.get_dummies(X, drop_first = True)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 30)

lin = LinearRegression(normalize=True, n_jobs=30)
lin.fit(X_train, y_train)

pred = lin.predict(X_test)

print(r2_score(y_test, pred))

joblib.dump(lin, "hp_model.ml")